import { useCallback, useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../../context/AuthContext'
import { supabase } from '../../../lib/supabaseClient'

// Dashboard KIA — Poli KIA
// Alur: antrian poli KIA hari ini -> pilih pasien -> skrining (TTV) + pemeriksaan KIA
//       (anamnesa, diagnosa, tindakan, resep) -> status kunjungan pindah ke 'menunggu_obat'
//       (atau 'selesai' jika tidak ada resep), sama seperti alur dokter poli umum.

const STATUS_ANTRIAN = ['menunggu', 'menunggu_dokter']

const JENIS_LAYANAN = [
  'ANC (Pemeriksaan Kehamilan)',
  'Nifas / PNC',
  'KB',
  'Imunisasi',
  'Pemeriksaan Bayi/Balita',
  'Lainnya',
]

const emptySkrining = { tekanan_darah: '', suhu: '', berat_badan: '', tinggi_badan: '', keluhan_utama: '' }
const emptyPeriksa = {
  jenis_layanan: JENIS_LAYANAN[0],
  hpht: '',
  usia_kehamilan: '',
  anamnesis: '',
  diagnosis: '',
  kode_icd: '',
  tindakan: '',
  catatan: '',
  rujukan: false,
  tujuan_rujukan: '',
}
const emptyResep = { nama_obat: '', dosis: '', aturan_pakai: '', jumlah: '' }

function hitungUmur(tglLahir) {
  if (!tglLahir) return '-'
  const lahir = new Date(tglLahir)
  const now = new Date()
  let umur = now.getFullYear() - lahir.getFullYear()
  const m = now.getMonth() - lahir.getMonth()
  if (m < 0 || (m === 0 && now.getDate() < lahir.getDate())) umur--
  return `${umur} th`
}

function hariIni() {
  const d = new Date()
  const z = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`
}

export default function DashboardKIA() {
  const { profile, signOut } = useAuth()
  const navigate = useNavigate()

  const [poliId, setPoliId] = useState(null)
  const [namaPoli, setNamaPoli] = useState('')
  const [antrian, setAntrian] = useState([])
  const [loading, setLoading] = useState(true)
  const [pesan, setPesan] = useState(null) // { tipe: 'ok'|'err', teks }
  const [terpilih, setTerpilih] = useState(null)
  const [skrining, setSkrining] = useState(emptySkrining)
  const [periksa, setPeriksa] = useState(emptyPeriksa)
  const [resep, setResep] = useState([])
  const [obatBaru, setObatBaru] = useState(emptyResep)
  const [menyimpan, setMenyimpan] = useState(false)
  const [riwayat, setRiwayat] = useState([])

  // ---- ambil poli milik bidan ----
  useEffect(() => {
    let batal = false
    async function muatPoli() {
      const { data: userData } = await supabase.auth.getUser()
      const uid = userData?.user?.id
      if (!uid) return
      const { data, error } = await supabase
        .from('profiles')
        .select('poli_id, polis:poli_id(nama_poli)')
        .eq('id', uid)
        .single()
      if (batal) return
      if (error || !data?.poli_id) {
        setPesan({ tipe: 'err', teks: 'Akun Anda belum ditempatkan di poli. Hubungi admin.' })
        setLoading(false)
        return
      }
      setPoliId(data.poli_id)
      setNamaPoli(data.polis?.nama_poli ?? '')
    }
    muatPoli()
    return () => {
      batal = true
    }
  }, [])

  // ---- muat antrian hari ini untuk poli bidan ----
  const muatAntrian = useCallback(async () => {
    if (!poliId) return
    setLoading(true)
    const { data, error } = await supabase
      .from('kunjungan')
      .select(
        'id, nomor_antrian, status, status_panggil, status_prioritas, tanggal_periksa, kategori_pasien, pasien:pasien_id(id, nama_lengkap, no_rekam_medis, tanggal_lahir, jenis_kelamin, alergi_obat), skrining(id, tekanan_darah, suhu, berat_badan, tinggi_badan, keluhan_utama, triase)'
      )
      .eq('poli_id', poliId)
      .eq('tanggal_periksa', hariIni())
      .in('status', STATUS_ANTRIAN)
      .order('nomor_antrian', { ascending: true })
    setLoading(false)
    if (error) {
      setPesan({ tipe: 'err', teks: 'Gagal memuat antrian: ' + error.message })
      return
    }
    setAntrian(data ?? [])
  }, [poliId])

  useEffect(() => {
    muatAntrian()
  }, [muatAntrian])

  // refresh otomatis tiap 30 detik
  useEffect(() => {
    if (!poliId) return
    const t = setInterval(muatAntrian, 30000)
    return () => clearInterval(t)
  }, [poliId, muatAntrian])

  // ---- pilih pasien ----
  async function pilihPasien(k) {
    setPesan(null)
    setTerpilih(k)
    const sk = Array.isArray(k.skrining) ? k.skrining[0] : k.skrining
    setSkrining(
      sk
        ? {
            tekanan_darah: sk.tekanan_darah ?? '',
            suhu: sk.suhu ?? '',
            berat_badan: sk.berat_badan ?? '',
            tinggi_badan: sk.tinggi_badan ?? '',
            keluhan_utama: sk.keluhan_utama ?? '',
          }
        : emptySkrining
    )
    setPeriksa(emptyPeriksa)
    setResep([])
    setObatBaru(emptyResep)

    // tandai dipanggil
    await supabase
      .from('kunjungan')
      .update({ status_panggil: 'dipanggil', waktu_panggil: new Date().toISOString() })
      .eq('id', k.id)

    // riwayat kunjungan sebelumnya
    const { data } = await supabase
      .from('kunjungan')
      .select('id, tanggal_periksa, diagnosa, anamnesa, therapy_tindakan')
      .eq('pasien_id', k.pasien?.id)
      .neq('id', k.id)
      .order('tanggal_periksa', { ascending: false })
      .limit(5)
    setRiwayat(data ?? [])
  }

  function tambahObat() {
    if (!obatBaru.nama_obat.trim()) return
    setResep((r) => [...r, { ...obatBaru, nama_obat: obatBaru.nama_obat.trim() }])
    setObatBaru(emptyResep)
  }

  function hapusObat(i) {
    setResep((r) => r.filter((_, idx) => idx !== i))
  }

  // ---- simpan skrining + pemeriksaan + resep ----
  async function simpan() {
    if (!terpilih) return
    if (!periksa.diagnosis.trim()) {
      setPesan({ tipe: 'err', teks: 'Diagnosis wajib diisi.' })
      return
    }
    if (periksa.rujukan && !periksa.tujuan_rujukan.trim()) {
      setPesan({ tipe: 'err', teks: 'Tujuan rujukan wajib diisi.' })
      return
    }

    setMenyimpan(true)
    setPesan(null)
    const { data: userData } = await supabase.auth.getUser()
    const uid = userData?.user?.id
    const kunjunganId = terpilih.id

    try {
      // 1. skrining (TTV) — update jika sudah ada, insert jika belum
      const skAda = Array.isArray(terpilih.skrining) ? terpilih.skrining[0] : terpilih.skrining
      const skPayload = {
        tekanan_darah: skrining.tekanan_darah || null,
        suhu: skrining.suhu === '' ? null : Number(skrining.suhu),
        berat_badan: skrining.berat_badan === '' ? null : Number(skrining.berat_badan),
        tinggi_badan: skrining.tinggi_badan === '' ? null : Number(skrining.tinggi_badan),
        keluhan_utama: skrining.keluhan_utama || null,
      }
      if (skAda?.id) {
        const { error } = await supabase.from('skrining').update(skPayload).eq('id', skAda.id)
        if (error) throw error
      } else {
        const { error } = await supabase
          .from('skrining')
          .insert({ ...skPayload, kunjungan_id: kunjunganId, perawat_id: uid })
        if (error) throw error
      }

      // 2. pemeriksaan — info khusus KIA dimasukkan ke kolom catatan (tidak perlu ubah skema)
      const infoKia = [
        `Layanan: ${periksa.jenis_layanan}`,
        periksa.hpht ? `HPHT: ${periksa.hpht}` : null,
        periksa.usia_kehamilan ? `Usia kehamilan: ${periksa.usia_kehamilan} minggu` : null,
        periksa.catatan ? periksa.catatan : null,
      ]
        .filter(Boolean)
        .join(' | ')

      const { data: pem, error: pemErr } = await supabase
        .from('pemeriksaan')
        .insert({
          kunjungan_id: kunjunganId,
          dokter_id: uid, // kolom ini menyimpan id petugas pemeriksa (di sini: bidan)
          anamnesis: periksa.anamnesis || null,
          diagnosis: periksa.diagnosis.trim(),
          kode_icd: periksa.kode_icd || null,
          tindakan: periksa.tindakan || null,
          rujukan: periksa.rujukan,
          tujuan_rujukan: periksa.rujukan ? periksa.tujuan_rujukan : null,
          catatan: infoKia,
        })
        .select('id')
        .single()
      if (pemErr) throw pemErr

      // 3. resep
      if (resep.length > 0) {
        const rows = resep.map((r) => ({
          pemeriksaan_id: pem.id,
          kunjungan_id: kunjunganId,
          nama_obat: r.nama_obat,
          dosis: r.dosis || null,
          aturan_pakai: r.aturan_pakai || null,
          jumlah: r.jumlah === '' ? null : Number(r.jumlah),
        }))
        const { error } = await supabase.from('resep').insert(rows)
        if (error) throw error
      }

      // 4. ringkasan di kunjungan + pindah status
      const statusBaru = resep.length > 0 ? 'menunggu_obat' : 'selesai'
      const { error: kErr } = await supabase
        .from('kunjungan')
        .update({
          anamnesa: periksa.anamnesis || null,
          diagnosa: periksa.diagnosis.trim(),
          icd_x: periksa.kode_icd || null,
          therapy_tindakan: periksa.tindakan || null,
          petugas_poli_id: uid,
          status: statusBaru,
          status_panggil: 'selesai',
        })
        .eq('id', kunjunganId)
      if (kErr) throw kErr

      setPesan({
        tipe: 'ok',
        teks:
          statusBaru === 'menunggu_obat'
            ? 'Tersimpan. Pasien diteruskan ke apotek.'
            : 'Tersimpan. Kunjungan selesai.',
      })
      setTerpilih(null)
      setRiwayat([])
      muatAntrian()
    } catch (e) {
      setPesan({ tipe: 'err', teks: 'Gagal menyimpan: ' + (e?.message ?? 'kesalahan tidak dikenal') })
    } finally {
      setMenyimpan(false)
    }
  }

  async function batalPilih() {
    if (terpilih) {
      // kembalikan status panggil agar pasien tetap ada di antrian
      await supabase.from('kunjungan').update({ status_panggil: 'menunggu' }).eq('id', terpilih.id)
    }
    setTerpilih(null)
    setRiwayat([])
    muatAntrian()
  }

  async function keluar() {
    await signOut?.()
    navigate('/')
  }

  const namaBidan = profile?.nama_lengkap ?? ''
  const jumlahAntrian = useMemo(() => antrian.length, [antrian])

  // ---- gaya ----
  const kartu = {
    background: 'var(--surface, #fff)',
    border: '1px solid var(--line, #e5e7eb)',
    borderRadius: 16,
    padding: 20,
    boxShadow: '0 1px 2px rgba(18,24,27,0.04), 0 8px 24px rgba(18,24,27,0.04)',
  }
  const input = {
    width: '100%',
    boxSizing: 'border-box',
    padding: '9px 12px',
    borderRadius: 8,
    border: '1px solid var(--line, #e5e7eb)',
    background: '#fff',
    color: 'var(--ink, #12181b)',
    fontSize: 14,
    outline: 'none',
  }
  const label = { display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12, fontWeight: 600 }
  const tombol = (aktif = true, warna = 'var(--accent, #0f7b64)') => ({
    padding: '9px 16px',
    borderRadius: 8,
    border: 'none',
    background: warna,
    color: '#fff',
    fontWeight: 600,
    fontSize: 13,
    cursor: aktif ? 'pointer' : 'not-allowed',
    opacity: aktif ? 1 : 0.6,
  })

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg, #f8fafb)', padding: '24px 16px' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        {/* header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0 }}>Dashboard KIA</h1>
            <p style={{ margin: '2px 0 0', fontSize: 13, color: 'var(--muted, #6b7280)' }}>
              {namaPoli || 'Poli KIA'} — Pemeriksaan Ibu &amp; Anak
              {namaBidan ? ` · ${namaBidan}` : ''}
            </p>
          </div>
          <button onClick={keluar} style={{ ...tombol(true, '#fff'), color: 'var(--ink, #12181b)', border: '1px solid var(--line, #e5e7eb)' }}>
            Keluar
          </button>
        </div>

        {pesan && (
          <p
            style={{
              padding: '10px 14px',
              borderRadius: 8,
              fontSize: 13,
              margin: '0 0 16px',
              background: pesan.tipe === 'ok' ? '#e7f6f1' : 'var(--danger-soft, #fde8e8)',
              color: pesan.tipe === 'ok' ? '#0f7b64' : 'var(--danger, #b42318)',
            }}
          >
            {pesan.teks}
          </p>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16, alignItems: 'start' }}>
          {/* ---- antrian ---- */}
          <div style={kartu}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>Antrian Hari Ini ({jumlahAntrian})</h2>
              <button onClick={muatAntrian} style={{ ...tombol(true, 'transparent'), color: 'var(--accent, #0f7b64)', padding: '4px 8px' }}>
                Refresh
              </button>
            </div>

            {loading ? (
              <p style={{ fontSize: 13, color: 'var(--muted, #6b7280)' }}>Memuat…</p>
            ) : antrian.length === 0 ? (
              <p style={{ fontSize: 13, textAlign: 'center', padding: '32px 0', color: 'var(--muted, #6b7280)' }}>
                Belum ada antrian Poli KIA hari ini.
              </p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {antrian.map((k) => {
                  const aktif = terpilih?.id === k.id
                  return (
                    <button
                      key={k.id}
                      onClick={() => pilihPasien(k)}
                      style={{
                        textAlign: 'left',
                        padding: '10px 12px',
                        borderRadius: 10,
                        cursor: 'pointer',
                        border: aktif ? '2px solid var(--accent, #0f7b64)' : '1px solid var(--line, #e5e7eb)',
                        background: aktif ? '#f0faf7' : '#fff',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 700 }}>
                        <span>
                          #{k.nomor_antrian ?? '-'} · {k.pasien?.nama_lengkap ?? '-'}
                        </span>
                        <span style={{ fontSize: 11, color: 'var(--muted, #6b7280)', fontWeight: 500 }}>
                          {k.status === 'menunggu' ? 'Belum skrining' : 'Sudah skrining'}
                        </span>
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--muted, #6b7280)', marginTop: 2 }}>
                        RM {k.pasien?.no_rekam_medis ?? '-'} · {hitungUmur(k.pasien?.tanggal_lahir)} ·{' '}
                        {k.pasien?.jenis_kelamin ?? '-'} · {k.kategori_pasien ?? '-'}
                      </div>
                    </button>
                  )
                })}
              </div>
            )}
          </div>

          {/* ---- form pemeriksaan ---- */}
          <div style={kartu}>
            {!terpilih ? (
              <div style={{ textAlign: 'center', padding: '48px 0', color: 'var(--muted, #6b7280)', fontSize: 13 }}>
                Pilih pasien dari antrian
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div>
                  <h2 style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>{terpilih.pasien?.nama_lengkap}</h2>
                  <p style={{ fontSize: 12, margin: '2px 0 0', color: 'var(--muted, #6b7280)' }}>
                    RM {terpilih.pasien?.no_rekam_medis ?? '-'} · {hitungUmur(terpilih.pasien?.tanggal_lahir)} ·{' '}
                    {terpilih.pasien?.jenis_kelamin ?? '-'}
                  </p>
                  {terpilih.pasien?.alergi_obat && (
                    <p style={{ fontSize: 12, margin: '6px 0 0', color: 'var(--danger, #b42318)', fontWeight: 600 }}>
                      Alergi obat: {terpilih.pasien.alergi_obat}
                    </p>
                  )}
                </div>

                {/* TTV */}
                <fieldset style={{ border: '1px solid var(--line, #e5e7eb)', borderRadius: 10, padding: 12 }}>
                  <legend style={{ fontSize: 12, fontWeight: 700, padding: '0 6px' }}>Tanda Vital</legend>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
                    <label style={label}>
                      Tekanan darah
                      <input style={input} placeholder="120/80" value={skrining.tekanan_darah} onChange={(e) => setSkrining({ ...skrining, tekanan_darah: e.target.value })} />
                    </label>
                    <label style={label}>
                      Suhu (°C)
                      <input style={input} type="number" step="0.1" value={skrining.suhu} onChange={(e) => setSkrining({ ...skrining, suhu: e.target.value })} />
                    </label>
                    <label style={label}>
                      Berat badan (kg)
                      <input style={input} type="number" step="0.1" value={skrining.berat_badan} onChange={(e) => setSkrining({ ...skrining, berat_badan: e.target.value })} />
                    </label>
                    <label style={label}>
                      Tinggi badan (cm)
                      <input style={input} type="number" step="0.1" value={skrining.tinggi_badan} onChange={(e) => setSkrining({ ...skrining, tinggi_badan: e.target.value })} />
                    </label>
                  </div>
                  <label style={{ ...label, marginTop: 10 }}>
                    Keluhan utama
                    <input style={input} value={skrining.keluhan_utama} onChange={(e) => setSkrining({ ...skrining, keluhan_utama: e.target.value })} />
                  </label>
                </fieldset>

                {/* pemeriksaan KIA */}
                <fieldset style={{ border: '1px solid var(--line, #e5e7eb)', borderRadius: 10, padding: 12 }}>
                  <legend style={{ fontSize: 12, fontWeight: 700, padding: '0 6px' }}>Pemeriksaan KIA</legend>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
                    <label style={{ ...label, gridColumn: '1 / -1' }}>
                      Jenis layanan
                      <select style={input} value={periksa.jenis_layanan} onChange={(e) => setPeriksa({ ...periksa, jenis_layanan: e.target.value })}>
                        {JENIS_LAYANAN.map((j) => (
                          <option key={j} value={j}>
                            {j}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label style={label}>
                      HPHT
                      <input style={input} type="date" value={periksa.hpht} onChange={(e) => setPeriksa({ ...periksa, hpht: e.target.value })} />
                    </label>
                    <label style={label}>
                      Usia kehamilan (minggu)
                      <input style={input} type="number" min="0" max="45" value={periksa.usia_kehamilan} onChange={(e) => setPeriksa({ ...periksa, usia_kehamilan: e.target.value })} />
                    </label>
                  </div>
                  <label style={{ ...label, marginTop: 10 }}>
                    Anamnesis
                    <textarea style={{ ...input, minHeight: 60, resize: 'vertical' }} value={periksa.anamnesis} onChange={(e) => setPeriksa({ ...periksa, anamnesis: e.target.value })} />
                  </label>
                  <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 10, marginTop: 10 }}>
                    <label style={label}>
                      Diagnosis *
                      <input style={input} value={periksa.diagnosis} onChange={(e) => setPeriksa({ ...periksa, diagnosis: e.target.value })} />
                    </label>
                    <label style={label}>
                      Kode ICD-10
                      <input style={input} value={periksa.kode_icd} onChange={(e) => setPeriksa({ ...periksa, kode_icd: e.target.value })} />
                    </label>
                  </div>
                  <label style={{ ...label, marginTop: 10 }}>
                    Tindakan / terapi
                    <textarea style={{ ...input, minHeight: 50, resize: 'vertical' }} value={periksa.tindakan} onChange={(e) => setPeriksa({ ...periksa, tindakan: e.target.value })} />
                  </label>
                  <label style={{ ...label, marginTop: 10 }}>
                    Catatan
                    <input style={input} value={periksa.catatan} onChange={(e) => setPeriksa({ ...periksa, catatan: e.target.value })} />
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, marginTop: 10 }}>
                    <input type="checkbox" checked={periksa.rujukan} onChange={(e) => setPeriksa({ ...periksa, rujukan: e.target.checked })} />
                    Rujuk pasien
                  </label>
                  {periksa.rujukan && (
                    <label style={{ ...label, marginTop: 8 }}>
                      Tujuan rujukan *
                      <input style={input} value={periksa.tujuan_rujukan} onChange={(e) => setPeriksa({ ...periksa, tujuan_rujukan: e.target.value })} />
                    </label>
                  )}
                </fieldset>

                {/* resep */}
                <fieldset style={{ border: '1px solid var(--line, #e5e7eb)', borderRadius: 10, padding: 12 }}>
                  <legend style={{ fontSize: 12, fontWeight: 700, padding: '0 6px' }}>Resep</legend>
                  {resep.length > 0 && (
                    <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 10px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                      {resep.map((r, i) => (
                        <li key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '6px 10px', background: '#f8fafb', borderRadius: 8 }}>
                          <span>
                            <b>{r.nama_obat}</b> {r.dosis && `· ${r.dosis}`} {r.aturan_pakai && `· ${r.aturan_pakai}`} {r.jumlah && `· jml ${r.jumlah}`}
                          </span>
                          <button type="button" onClick={() => hapusObat(i)} style={{ border: 'none', background: 'none', color: 'var(--danger, #b42318)', cursor: 'pointer', fontSize: 12 }}>
                            Hapus
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                  <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 8 }}>
                    <input style={input} placeholder="Nama obat" value={obatBaru.nama_obat} onChange={(e) => setObatBaru({ ...obatBaru, nama_obat: e.target.value })} />
                    <input style={input} placeholder="Dosis" value={obatBaru.dosis} onChange={(e) => setObatBaru({ ...obatBaru, dosis: e.target.value })} />
                    <input style={input} placeholder="Aturan" value={obatBaru.aturan_pakai} onChange={(e) => setObatBaru({ ...obatBaru, aturan_pakai: e.target.value })} />
                    <input style={input} type="number" min="0" placeholder="Jumlah" value={obatBaru.jumlah} onChange={(e) => setObatBaru({ ...obatBaru, jumlah: e.target.value })} />
                  </div>
                  <button type="button" onClick={tambahObat} style={{ ...tombol(true, '#fff'), color: 'var(--accent, #0f7b64)', border: '1px solid var(--accent, #0f7b64)', marginTop: 8 }}>
                    + Tambah obat
                  </button>
                </fieldset>

                {/* riwayat */}
                {riwayat.length > 0 && (
                  <details style={{ fontSize: 13 }}>
                    <summary style={{ cursor: 'pointer', fontWeight: 600 }}>Riwayat kunjungan ({riwayat.length})</summary>
                    <ul style={{ margin: '8px 0 0', paddingLeft: 18 }}>
                      {riwayat.map((r) => (
                        <li key={r.id} style={{ marginBottom: 4 }}>
                          {r.tanggal_periksa}: {r.diagnosa || '-'}
                          {r.therapy_tindakan ? ` — ${r.therapy_tindakan}` : ''}
                        </li>
                      ))}
                    </ul>
                  </details>
                )}

                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={simpan} disabled={menyimpan} style={tombol(!menyimpan)}>
                    {menyimpan ? 'Menyimpan…' : 'Simpan & Selesai'}
                  </button>
                  <button onClick={batalPilih} disabled={menyimpan} style={{ ...tombol(!menyimpan, '#fff'), color: 'var(--ink, #12181b)', border: '1px solid var(--line, #e5e7eb)' }}>
                    Batal
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}